<?php
$NameServer = "localhost";
$UserName = "root";
$Password = "";
$NameDba = "login";

$Connect = new mysqli($NameServer, $UserName, $Password, $NameDba);

if ($Connect->connect_error) {
    die("Error: " . $Connect->connect_error);
}
?>