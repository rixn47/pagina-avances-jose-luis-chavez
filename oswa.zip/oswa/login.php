<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .login-card .form-control {
            margin-bottom: 1rem;
            border-radius: 0.5rem;
        }
        .login-card a {
            text-decoration: none;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="login-card bg-white">
        <h2>Login</h2>
        <form>
            <input type="email" class="form-control" placeholder="Correo" required>
            <input type="password" class="form-control" placeholder="Contraseña" required>
            <button type="submit" class="btn btn-dark w-100">Login</button>
            <p class="mt-3">OLVIDASTE TU CONTRASEÑA? <a href="./includes/Recuperar_c.php">Sign Up</a></p>
        </form>
    </div>
    <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>