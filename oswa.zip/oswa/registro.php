<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .signup-card {
            width: 100%;
            max-width: 400px;
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        .signup-card .form-control {
            margin-bottom: 1rem;
            border-radius: 0.5rem;
        }
        .signup-card a {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="signup-card bg-white">
        <h2>REGISTRATE</h2>
        <form>
            <input type="text" class="form-control" placeholder="NOMBRE" required>
            <input type="text" class="form-control" placeholder="APELLIDOS" required>
            <input type="email" class="form-control" placeholder="Email" required>
            <input type="password" class="form-control" placeholder="contraseña" required>
            <input type="password" class="form-control" placeholder="Confirma tu contraseña" required><br>
            <button type="submit" class="btn btn-dark w-100">Iniciar Sesion</button>
            <p class="mt-3">INICIAR SESION? <a href="./login.php">LOGIN</a></p>
        </form>
    </div>
    <script src="./js/bootstrap.bundle.min.js"></script>
</body>
</html>